export function algorithm2 (input: number) {
  if (input <= 1) {
    console.log("Wrong given")
  } else {
    //outpur array of numbers
    let output: number[] = [];

    //math.floor for removing the bug for inputting odd numbers
    let k = Math.floor((input - 2) / 2);

    let integerList: boolean[] = new Array(k + 1).fill(true);

    for (let i = 1; i <= k; i++) {
      let j = i;

      while (i + j + 2 * i * j <= k) {
        integerList[i + j + 2 * i * j] = false;
        j += 1;
      }
    }

    if (input > 2) {
      output.push(2);
    }

    for (let i = 1; i <= k; i++) {
      if (integerList[i]) {
        output.push(2 * i + 1);
      }
    }
    return output;
  }
}

let try1 = algorithm2(11);
console.log(try1);


console.time('Execution Time');
algorithm2(10000);
console.timeEnd('Execution Time');

console.time('Execution Time');
algorithm2(1000000);
console.timeEnd('Execution Time');

console.time('Execution Time');
algorithm2(5000000);
console.timeEnd('Execution Time');